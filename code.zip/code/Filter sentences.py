import os
import re
import pandas as pd
from collections import defaultdict

# ---------------------- 1. 配置参数（词典、文件路径等） ----------------------
# 完整词典：基础关键词 + 制造业场景扩充关键词
DIGITAL_DICT = {
    "大数据": {
        "keywords": [
            "大数据", "海量数据", "异构数据", "big data", "对象储存", "分析型数据库", "关系型数据库",
            "键值数据库", "批量计算", "时序数据库", "数据集成", "数据建模", "数据可视化", "数据脱敏",
            "数据挖掘", "数据资源", "图数据库", "文档数据库", "隐私计算", "元数据管理", "数据资产",
            "数据管理平台", "数据技术", "EB级存储",
            "生产设备数据采集", "供应链数据看板", "产品质量数据追溯", "能耗数据监测", "预测性维护数据集",
            "车间数据湖", "制造执行系统（MES）数据", "客户需求数据分析", "产线能耗数据统计", "工厂质量数据台账",
            "设备运行日志分析", "供应链库存数据模型", "生产排程数据优化", "产品全生命周期数据管理"
        ],
        "stage_rule": "0：无大数据相关表述\n1：初始级：单一车间数据采集（无分析应用）、零散设备日志记录（无优化）\n2：单元级：产线能耗数据监测（降本5%+）、单一工厂质量数据追溯（不良品定位）\n3：流程级：供应链数据看板（采购-生产-库存数据互通）、跨车间生产数据联动分析\n4：网络级：全集团生产数据中台（总部+分支机构数据汇总）、跨地域销售数据联动预测\n5：生态级：产业链需求数据共享（上下游企业数据协同）、跨企业生产数据联动优化"
    },
    "人工智能": {
        "keywords": [
            "AI", "人工智能", "机器学习", "深度学习", "知识图谱", "自然语言处理", "计算机视觉",
            "生物特征识别", "神经网络", "监督学习", "无监督学习", "强化学习", "机器人", "人脸识别",
            "语音识别", "OCR", "语义理解", "个性化推荐", "Artificial Intelligence",
            "工业质检AI", "生产参数优化AI", "设备故障诊断AI", "供应链需求预测AI", "数字孪生AI建模",
            "AI排产系统", "装配机器人AI控制", "AI视觉缺陷检测", "AI设备剩余寿命预测", "AI供应链风险预警",
            "AI生产能耗优化", "AI产品设计辅助", "AI质量追溯分析", "AI仓储机器人调度", "AI订单智能分配",
            "工业机器人", "智能焊接", "自动化产线", "机器人标定", "机器人碰撞保护", "机器人操作机"
        ],
        "stage_rule": "0：无人工智能/工业机器人表述\n1：初始级：单台工业机器人试用（无协同）\n2：单元级：工业机器人产线集成（单一环节自动化）\n3：流程级：多机器人跨工序协同（如焊接+装配联动）"
    },
    "移动互联": {
        "keywords": [
            "4G", "5G", "3G", "无线局域网（WLAN）", "移动支付", "移动办公", "APP", "移动智能终端",
            "智能手机", "LBS", "移动导航", "移动协同",
            "5G工业网关", "设备远程移动监控APP", "车间移动巡检系统", "供应链移动协同平台", "移动质检终端",
            "5G+AR远程维修", "移动生产报工系统", "设备移动调试工具", "移动库存盘点APP", "移动订单跟踪系统",
            "5G+AI移动质检", "移动设备运维工单系统", "移动生产看板", "移动协同研发平台"
        ],
        "stage_rule": "0：无移动互联相关表述\n1：初始级：单一设备移动监控（无远程控制）、局部移动办公试用（无协同）\n2：单元级：车间移动巡检（问题响应提速20%+）、单一设备移动控制（远程调试）\n3：流程级：5G+AR跨部门远程维修（研发-售后协同）、跨部门移动协同平台（采购-生产订单同步）\n4：网络级：全集团移动生产报工平台（多地域工厂数据同步）、集团级移动办公协同系统\n5：生态级：产业链移动协同平台（上下游订单实时同步）、跨企业移动运维平台（供应商设备远程协助）"
    },
    "云计算": {
        "keywords": [
            "云计算", "公有云", "私有云", "混合云", "IaaS", "PaaS", "SaaS", "云平台", "云存储",
            "云数据中心", "虚拟化技术", "工业云", "云原生技术",
            "工业私有云", "云端PLM（产品生命周期管理）", "制造SaaS软件（ERP/MES云化）", "云端协同研发平台",
            "云原生制造数据中心", "跨地域云边协同", "车间级私有云", "工厂级混合云", "集团级工业云平台",
            "云化MES系统", "云化供应链管理软件", "云端设备管理平台", "云原生生产数据中台"
        ],
        "stage_rule": "0：无云计算相关表述\n1：初始级：单一部门云盘试用（无业务应用）、局部云存储（无数据共享）\n2：单元级：车间级私有云（生产数据存储）、单一工厂ERP云化（效率提升10%+）\n3：流程级：云端协同研发平台（研发-生产数据互通）、跨部门云化ERP（采购-生产-库存协同）\n4：网络级：全集团混合云制造平台（总部+子公司数据互通）、集团级云数据中心（多工厂资源调度）\n5：生态级：工业云生态平台（开放API给合作伙伴）、产业链云协同平台（上下游企业云化协同）"
    },
    "物联网": {
        "keywords": [
            "物联网", "IoT", "RFID", "传感器", "无线传感", "M2M", "NB-IoT", "工业物联网",
            "射频识别", "传感网", "边缘计算",
            "工业传感器（温度/振动/压力）", "RFID产品溯源", "车间物联网网关", "设备物联平台（IIoT）",
            "智能仓储物联网", "产线物料物联网", "能源物联网监测", "设备状态物联网监测", "车间无线传感网络",
            "工业物联网平台", "物联网数据采集终端", "RFID物料跟踪", "物联网设备协同控制"
        ],
        "stage_rule": "0：无物联网相关表述\n1：初始级：单台设备传感器部署（无数据联动）、局部RFID试用（无溯源应用）\n2：单元级：车间物料物联网（库存准确率提升20%+）、单一产线设备互联（生产协同）\n3：流程级：产线-仓储物联网互通（物料周转提速30%+）、跨车间设备物联网协同（维修资源调度）\n4：网络级：全组织设备物联平台（多工厂设备互联）、跨地域能源物联网监测（集团能耗管控）\n5：生态级：产业链物联网溯源（供应商-工厂-客户全链路）、跨企业设备物联网协同（合作伙伴设备状态共享）"
    },
    "区块链": {
        "keywords": [
            "区块链", "分布式账本", "智能合约", "去中心化", "公有链", "私有链", "联盟链", "数字资产",
            "零部件溯源区块链", "供应链金融区块链（应收账款确权）", "制造过程数据存证区块链", "供应商资质区块链",
            "产品质量区块链存证", "工业区块链平台", "区块链+供应链协同", "区块链+设备溯源", "联盟链供应链管理"
        ],
        "stage_rule": "0：无区块链相关表述\n1：初始级：单一零部件区块链记录（无共享）、局部数据存证测试（无业务应用）\n2：单元级：工厂内部质量数据存证（可追溯）、单一零部件区块链溯源（工厂内流转）\n3：流程级：供应链应收账款区块链（采购-财务协同确权）、跨部门产品质量存证区块链（生产-质检协同）\n4：网络级：全集团供应商资质区块链（多工厂共享）、跨地域产品溯源区块链（集团内多基地）\n5：生态级：产业链产品溯源区块链（上下游全链路）、跨企业供应链金融区块链（多主体协同融资）"
    }
}

# 年度报告根文件夹（按年份分文件夹）
ROOT_FOLDER = r"D:\桌面\LLM文本分析\龙头数据"  # 替换为你的实际路径
# 输出Excel路径
OUTPUT_EXCEL = r"D:\桌面\制造业数字化转型完整句子筛选结果1.xlsx"

# ---------------------- 2. 核心函数：从单篇TXT提取含关键词的完整句子 ----------------------
def extract_complete_sentences(txt_path, company_name, year):
    """
    从单个TXT文件中提取含关键词的完整句子
    :param txt_path: TXT文件路径
    :param company_name: 公司名称
    :param year: 年份
    :return: 含关键词的完整句子列表（每个元素为字典）
    """
    results = []
    # 读取TXT文件（处理常见编码问题）
    try:
        with open(txt_path, "r", encoding="utf-8") as f:
            content = f.read()
    except UnicodeDecodeError:
        try:
            with open(txt_path, "r", encoding="gbk") as f:
                content = f.read()
        except:
            print(f"⚠️  {txt_path} 编码异常，跳过处理")
            return results

    # 步骤1：按段落分割（空行分隔，避免跨段落断句）
    paragraphs = re.split(r"\n\s*\n", content)
    for para in paragraphs:
        para = para.strip()
        if not para:
            continue

        # 步骤2：按标点分句（保留中文和英文标点，确保语义完整）
        sentences = re.split(r"(?<=[。；！？.!?])\s*", para)
        for sent in sentences:
            sent = sent.strip()
            # 步骤3：过滤短句子和过长句子（保留15-500字的句子，确保语义完整）
            if 15 <= len(sent) <= 500:
                # 步骤4：匹配6类技术的关键词
                matched_techs = defaultdict(list)
                for tech_type, tech_info in DIGITAL_DICT.items():
                    for keyword in tech_info["keywords"]:
                        if keyword in sent:
                            matched_techs[tech_type].append(keyword)

                # 若匹配到关键词，记录结果
                if matched_techs:
                    results.append({
                        "年份": year,
                        "公司名称": company_name,
                        "文件路径": txt_path,
                        "完整句子": sent,
                        "匹配的技术类型": "|".join(matched_techs.keys()),
                        "匹配的关键词": "|".join([f"{tech}:{','.join(kwds)}" for tech, kwds in matched_techs.items()]),
                        # 人工标注列（空值，供后续填写）
                        "人工判断（是否真实转型）": "",  # 选项：是/否/不确定
                        "判断依据（参考词典规则）": "",  # 可复制对应技术的阶段规则
                        "单句对应技术阶段（暂填）": "",  # 如“人工智能-单元级”
                        "公司6分类标签（最终）": ""  # 选项：0/1/2/3/4/5
                    })
    return results

# ---------------------- 3. 批量处理所有年份文件夹 ----------------------
def batch_process_all_years(root_folder):
    """
    批量处理根文件夹下的所有年份文件夹
    :param root_folder: 年度报告根文件夹路径
    :return: 包含所有筛选结果的DataFrame
    """
    all_results = []

    # 遍历根文件夹中的年份文件夹（假设文件夹名是纯数字年份，如“2006”“2007”）
    for year_folder_name in os.listdir(root_folder):
        year_folder_path = os.path.join(root_folder, year_folder_name)
        # 仅处理文件夹，且文件夹名是年份（避免非年份文件夹干扰）
        if os.path.isdir(year_folder_path) and year_folder_name.isdigit():
            year = int(year_folder_name)
            print(f"\n=== 开始处理 {year} 年文件夹 ===")

            # 遍历年份文件夹下的所有TXT文件
            for filename in os.listdir(year_folder_path):
                if filename.endswith(".txt"):
                    txt_path = os.path.join(year_folder_path, filename)
                    # 提取公司名称（假设文件名格式：“A000518四环生物2006年年度报告.txt”）
                    company_match = re.search(r"A\d+([^2]+)\d+年年度报告", filename)
                    company_name = company_match.group(1).strip() if company_match else "未知公司"
                    print(f"  正在处理：{company_name} - {filename}")

                    # 提取含关键词的完整句子
                    sentences = extract_complete_sentences(txt_path, company_name, year)
                    all_results.extend(sentences)

    # 构建Excel：2个工作表（筛选结果 + 词典规则）
    with pd.ExcelWriter(OUTPUT_EXCEL, engine="openpyxl") as writer:
        # 工作表1：筛选结果（供人工标注）
        result_df = pd.DataFrame(all_results)
        result_df.to_excel(writer, sheet_name="完整句子筛选结果", index=False)

        # 工作表2：词典阶段规则（供标注参考）
        rule_data = []
        for tech_type, tech_info in DIGITAL_DICT.items():
            rule_data.append({
                "技术类型": tech_type,
                "基础+制造业场景关键词（共{}个）".format(len(tech_info["keywords"])): ",".join(tech_info["keywords"][:10]) + "..." if len(tech_info["keywords"]) > 10 else ",".join(tech_info["keywords"]),
                "6分类阶段适配规则": tech_info["stage_rule"]
            })
        rule_df = pd.DataFrame(rule_data)
        rule_df.to_excel(writer, sheet_name="词典阶段规则", index=False)

    print(f"\n✅ 所有年份处理完成！")
    print(f"📊 共筛选出 {len(all_results)} 条含关键词的完整句子")
    print(f"📁 结果已保存至：{OUTPUT_EXCEL}（含2个工作表）")
    return result_df

# ---------------------- 4. 执行批量处理 ----------------------
if __name__ == "__main__":
    # 安装依赖（首次运行需执行）：pip install pandas openpyxl
    batch_process_all_years(ROOT_FOLDER)