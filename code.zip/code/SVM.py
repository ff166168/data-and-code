import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import precision_score, accuracy_score, recall_score, f1_score

# ---------------------- 1. 配置参数 ----------------------
# 数据路径（Excel文件）
data_path = r"D:\桌面\excelexp_tfidf_cleaned.xlsx"
# 2分类标签列名（实际列名）
binary_label_col = "是否真实转型"
# 6分类标签列名（实际列名）
multi_label_col = "公司6分类标签"
# 随机种子（确保结果可复现）
random_seed = 42


# ---------------------- 2. 数据加载与预处理 ----------------------
def load_data(path):
    """加载数据，处理标签中的“缺省”值（设为0），分离特征和标签"""
    # 读取Excel文件
    df = pd.read_excel(path)
    
    # 提取TF-IDF特征列（排除文本列和标签列）
    text_cols = ["完整句子", "cleaned_text", "tokenized_text"]  # 文本列名（根据实际调整）
    feature_cols = [col for col in df.columns if col not in text_cols + [binary_label_col, multi_label_col]]
    X = df[feature_cols].values  # 特征矩阵
    
    # ---------------------- 处理2分类标签 ----------------------
    y_binary = df[binary_label_col]
    # 将“缺省”值设为0
    y_binary = y_binary.replace("缺省", 0)
    # 其他缺失值也填充为0
    y_binary = y_binary.fillna(0)
    # 转换为整数类型
    y_binary = y_binary.astype(int)
    # 过滤异常标签（只保留0和1，确保符合二分类要求）
    valid_binary = (y_binary == 0) | (y_binary == 1)
    X_binary = X[valid_binary]
    y_binary = y_binary[valid_binary]
    
    # ---------------------- 处理6分类标签 ----------------------
    y_multi = df[multi_label_col]
    # 将“缺省”值设为0
    y_multi = y_multi.replace("缺省", 0)
    # 其他缺失值填充为0
    y_multi = y_multi.fillna(0)
    # 转换为整数类型
    y_multi = y_multi.astype(int)
    # 过滤异常标签（只保留0-5，确保符合6分类要求）
    valid_multi = (y_multi >= 0) & (y_multi <= 5)
    X_multi = X[valid_multi]
    y_multi = y_multi[valid_multi]
    
    # 打印数据基本信息
    print(f"2分类数据：{X_binary.shape[0]}条样本，{X_binary.shape[1]}个特征")
    print(f"6分类数据：{X_multi.shape[0]}条样本，{X_multi.shape[1]}个特征")
    
    return X_binary, y_binary, X_multi, y_multi


# ---------------------- 3. 数据集划分（8:1:1） ----------------------
def split_data(X, y, test_size=0.1, val_size=0.1, random_state=42):
    """按8:1:1划分训练集、验证集、测试集"""
    # 先划分训练集（80%）和临时集（20%）
    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=test_size + val_size, random_state=random_state
    )
    # 再将临时集划分为验证集（10%）和测试集（10%）
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=test_size / (test_size + val_size), random_state=random_state
    )
    return X_train, X_val, X_test, y_train, y_val, y_test


# ---------------------- 4. 模型训练与评估 ----------------------
def train_evaluate_svm(X_train, X_val, X_test, y_train, y_val, y_test, is_binary=True):
    """训练SVM模型并计算评估指标"""
    # 初始化SVM模型（多分类默认使用“一对多”策略）
    svm = SVC(kernel="rbf", C=1.0, random_state=random_seed, probability=True)
    
    # 训练模型
    print("\n开始训练SVM模型...")
    svm.fit(X_train, y_train)
    
    # 预测（训练集、验证集、测试集）
    y_pred_train = svm.predict(X_train)
    y_pred_val = svm.predict(X_val)
    y_pred_test = svm.predict(X_test)
    
    # 评估指标计算（二分类用binary平均，多分类用weighted平均）
    average = "binary" if is_binary else "weighted"
    metrics = {
        "train": {
            "Accuracy": accuracy_score(y_train, y_pred_train),
            "Precision": precision_score(y_train, y_pred_train, average=average),
            "Recall": recall_score(y_train, y_pred_train, average=average),
            "F1-Score": f1_score(y_train, y_pred_train, average=average)
        },
        "val": {
            "Accuracy": accuracy_score(y_val, y_pred_val),
            "Precision": precision_score(y_val, y_pred_val, average=average),
            "Recall": recall_score(y_val, y_pred_val, average=average),
            "F1-Score": f1_score(y_val, y_pred_val, average=average)
        },
        "test": {
            "Accuracy": accuracy_score(y_test, y_pred_test),
            "Precision": precision_score(y_test, y_pred_test, average=average),
            "Recall": recall_score(y_test, y_pred_test, average=average),
            "F1-Score": f1_score(y_test, y_pred_test, average=average)
        }
    }
    return metrics


# ---------------------- 5. 主函数（执行流程） ----------------------
if __name__ == "__main__":
    # 加载并预处理数据
    X_binary, y_binary, X_multi, y_multi = load_data(data_path)
    
    # 执行2分类任务
    print("\n===== 2分类任务结果 =====")
    X_train_b, X_val_b, X_test_b, y_train_b, y_val_b, y_test_b = split_data(
        X_binary, y_binary, random_state=random_seed
    )
    binary_metrics = train_evaluate_svm(
        X_train_b, X_val_b, X_test_b, y_train_b, y_val_b, y_test_b, is_binary=True
    )
    # 打印2分类指标
    for data_type, metric in binary_metrics.items():
        print(f"\n{data_type}集指标：")
        for name, value in metric.items():
            print(f"{name}: {value:.4f}")
    
    # 执行6分类任务
    print("\n===== 6分类任务结果 =====")
    X_train_m, X_val_m, X_test_m, y_train_m, y_val_m, y_test_m = split_data(
        X_multi, y_multi, random_state=random_seed
    )
    multi_metrics = train_evaluate_svm(
        X_train_m, X_val_m, X_test_m, y_train_m, y_val_m, y_test_m, is_binary=False
    )
    # 打印6分类指标
    for data_type, metric in multi_metrics.items():
        print(f"\n{data_type}集指标：")
        for name, value in metric.items():
            print(f"{name}: {value:.4f}")