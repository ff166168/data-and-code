import pandas as pd
import re
import jieba
from sklearn.feature_extraction.text import TfidfVectorizer

# ---------------------- 1. 配置参数 ----------------------
# 文件路径
excel_file_path = r"D:\桌面\excelexp.xlsx"
dict_file_path = r"D:\桌面\词典 - 制造业.docx"
stopwords_file_path = r"D:\桌面\停用词\停用词3491.txt"
output_csv_path = r"D:\桌面\excelexp_tfidf_result.csv"

# 文本列名
text_column = "完整句子"

# TF-IDF参数
max_features = 1000  # 保留的最大特征词数量
ngram_range = (1, 2)  # 考虑1元词和2元词

# ---------------------- 2. 加载词典和停用词 ----------------------
# 加载自定义词典（.docx格式需先读取文本内容，这里假设词典是每行一个词的格式）
try:
    with open(dict_file_path, 'r', encoding='utf-8') as f:
        custom_dict = [line.strip() for line in f.readlines()]
    jieba.load_userdict(custom_dict)
    print("自定义词典加载成功，共加载 {} 个词".format(len(custom_dict)))
except Exception as e:
    print("加载自定义词典失败：", e)
    # 如果加载失败，使用jieba默认词典
    custom_dict = []

# 加载停用词
try:
    with open(stopwords_file_path, 'r', encoding='utf-8') as f:
        stopwords = [line.strip() for line in f.readlines()]
    print("停用词加载成功，共加载 {} 个停用词".format(len(stopwords)))
except Exception as e:
    print("加载停用词失败：", e)
    stopwords = []

# ---------------------- 3. 文本预处理函数 ----------------------
def clean_text(text):
    """清洗文本：去除特殊字符、数字、多余空格"""
    if pd.isna(text):
        return ""
    text = str(text)
    text = re.sub(r"[^\u4e00-\u9fa5a-zA-Z\s]", "", text)
    text = re.sub(r"\d+", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def tokenize_text(text):
    """中文分词：使用jieba拆分词语，返回空格连接的字符串"""
    if not text:
        return ""
    words = jieba.lcut(text)
    # 去除停用词
    words = [word for word in words if word not in stopwords]
    return " ".join(words)

# ---------------------- 4. 主流程：读取数据→预处理→TF-IDF向量化 ----------------------
if __name__ == "__main__":
    # 读取Excel数据
    df = pd.read_excel(excel_file_path)
    print(f"成功读取数据，共{len(df)}条记录")
    print("原始数据列名：", df.columns.tolist())

    # 检查文本列是否存在
    if text_column not in df.columns:
        raise ValueError(f"Excel中未找到'{text_column}'列，请检查列名是否正确！")

    # 文本预处理（清洗+分词）
    print("开始文本预处理...")
    df["cleaned_text"] = df[text_column].apply(clean_text)
    df["tokenized_text"] = df["cleaned_text"].apply(tokenize_text)
    print("预处理完成，示例结果：")
    print(df[[text_column, "cleaned_text", "tokenized_text"]].head())

    # TF-IDF向量化
    print("开始TF-IDF向量化...")
    tfidf = TfidfVectorizer(
        max_features=max_features,
        ngram_range=ngram_range,
        stop_words=stopwords,
        min_df=2,
        max_df=0.8
    )
    tfidf_matrix = tfidf.fit_transform(df["tokenized_text"])

    # 获取特征词列表
    feature_words = tfidf.get_feature_names_out()
    print(f"TF-IDF完成，共提取{len(feature_words)}个特征词")
    print("前20个特征词：", feature_words[:20])

    # 保存结果（原始数据+清洗分词结果+TF-IDF特征）
    tfidf_df = pd.DataFrame(
        tfidf_matrix.toarray(),
        columns=feature_words,
        index=df.index
    )
    result_df = pd.concat([df, tfidf_df], axis=1)
    result_df.to_csv(output_csv_path, index=False, encoding="utf-8-sig")
    print(f"结果已保存至：{output_csv_path}")