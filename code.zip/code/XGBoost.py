import pandas as pd
import re
import jieba
import os  # 新增：解决编码问题的环境设置
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split, StratifiedKFold
from xgboost import XGBClassifier  # XGBoost核心库
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from imblearn.over_sampling import SMOTE
import warnings
warnings.filterwarnings('ignore')

# ====================== 新增：导入拼写校正和词干处理库（兼容导入失败） ======================
try:
    import pycorrector  # 中文拼写校正
    import synonyms     # 中文同义词替换（模拟词干提取）
    CORRECT_AVAILABLE = True
    STEM_AVAILABLE = True
except ImportError:
    CORRECT_AVAILABLE = False
    STEM_AVAILABLE = False
    print("⚠️ 未安装pycorrector/synonyms，跳过拼写校正/词干处理（不影响代码运行）")

# ========== 新增：强制编码为UTF-8，解决UnicodeEncodeError ==========
os.environ['PYTHONIOENCODING'] = 'utf-8'
os.environ['LC_ALL'] = 'C.UTF-8'

# ---------------------- 1. 配置参数（核心：固定原始测试集，不参与拆分） ----------------------
train_val_file = r"D:\桌面\LLM\训练验证集.xlsx"
test_file_original = r"D:\桌面\LLM\测试集.xlsx"  # 原始测试集固定为最终测试集
dict_file = r"D:\桌面\ML\关键词.txt"
stopwords_file = r"D:\桌面\数据\停用词\停用词3491.txt"

# 结果路径（标注“XGBoost”和“固定测试集”）
cv_result_path = r"D:\桌面\XGBoost_5折交叉验证结果_固定100测试集.csv"
test_result_path = r"D:\桌面\XGBoost_测试集结果_固定100测试集.csv"

text_column = "句子"
six_class_label = "六分类"
random_seed = 42  # 保持随机种子一致，确保可复现
num_classes = 6  # 六分类任务，指定类别数

def convert_to_binary(label):
    return 0 if label == 0 else 1  # 二分类规则不变

# 特征参数（完全不变，保证对比公平）
tfidf_params = {
    "max_features": 600,
    "ngram_range": (1, 2),
    "min_df": 3,
    "max_df": 0.8
}

# ========== 替换：XGBoost模型参数（适配多分类任务） ==========
xgb_params = {
    "n_estimators": 200,  # 决策树数量
    "max_depth": 6,       # 树的最大深度（防止过拟合）
    "learning_rate": 0.1, # 学习率
    "subsample": 0.8,     # 样本采样比例（防止过拟合）
    "colsample_bytree": 0.8,  # 特征采样比例（防止过拟合）
    "objective": "multi:softmax",  # 多分类目标（输出类别）
    "num_class": num_classes,      # 六分类任务，指定类别数
    "random_state": random_seed,
    "n_jobs": -1,         # 并行计算（使用所有CPU核心）
    "verbosity": 0,       # 关闭训练日志
    "eval_metric": "mlogloss"  # 多分类损失函数
}

cv_folds = 5  # 交叉验证折数不变

# ---------------------- 2. 加载词典+停用词（完全不变） ----------------------
try:
    with open(dict_file, 'r', encoding='utf-8') as f:
        dict_content = f.read().strip()
        custom_dict = re.split(r'[，、\s;；\n\r]+', dict_content)
        custom_dict = list({word.strip() for word in custom_dict if word.strip()})
    jieba.load_userdict(custom_dict)
    print(f"✅ 自定义关键词词典加载成功：共{len(custom_dict)}个词（已去重）")
except Exception as e:
    print(f"❌ 词典加载失败：{e}")
    custom_dict = []

try:
    with open(stopwords_file, 'r', encoding='utf-8') as f:
        stopwords = [line.strip() for line in f.readlines() if line.strip()]
    print(f"✅ 停用词加载成功：{len(stopwords)} 个")
except Exception as e:
    print(f"❌ 停用词加载失败：{e}")
    stopwords = []

# ---------------------- 3. 文本预处理（增强：拼写校正+词干提取+标点处理+停用词去除+无样本过滤） ----------------------
def clean_text(text):
    """清洗文本：处理空值、标点符号、数字，归一化空格（标点处理核心步骤）"""
    if pd.isna(text):
        return ""
    text = str(text).strip()
    # 保留中文、英文和空格，移除其他字符（标点符号处理）
    text = re.sub(r"[^\u4e00-\u9fa5a-zA-Z\s]", "", text)
    # 移除数字
    text = re.sub(r"\d+", "", text)
    # 归一化多个空格为单个
    text = re.sub(r"\s+", " ", text).strip()
    return text

def spell_correct(text):
    """中文拼写校正（兼容库不可用的情况）"""
    if not CORRECT_AVAILABLE or not text:
        return text
    try:
        # pycorrector校正返回(校正后文本, 校正记录)
        corrected_text, _ = pycorrector.correct(text)
        return corrected_text
    except Exception:
        return text  # 出错时返回原文本

def stem_text(words):
    """中文词干提取（同义词替换模拟，兼容库不可用的情况）"""
    if not STEM_AVAILABLE or not words:
        return words
    stemmed_words = []
    for word in words:
        try:
            # 获取同义词（取第一个同义词作为词干，无则保留原词）
            syns = synonyms.nearby(word)[0]
            stem_word = syns[1] if len(syns) > 1 else word
            stemmed_words.append(stem_word)
        except Exception:
            stemmed_words.append(word)
    return stemmed_words

def tokenize_text(text):
    """分词：jieba分词 + 停用词去除 + 短词过滤 + 词干提取"""
    if not text:
        return ""
    words = jieba.lcut(text)
    # 过滤停用词和长度<=1的词（停用词去除核心步骤）
    words = [word for word in words if word not in stopwords and len(word) > 1]
    # 词干提取（同义词替换）
    words = stem_text(words)
    return " ".join(words)

# ---------------------- 4. 核心逻辑：固定测试集，仅拆分训练验证集（无样本过滤） ----------------------
if __name__ == "__main__":
    # ========== 步骤1：分离原始测试集，不参与合并拆分 ==========
    print("\n📥 读取数据（固定原始测试集）...")
    # 显式指定engine='openpyxl'，兼容新版Excel（.xlsx）
    df_train_val = pd.read_excel(train_val_file, engine='openpyxl')
    df_train_val["数据来源"] = "训练验证集"
    df_test_original = pd.read_excel(test_file_original, engine='openpyxl')
    df_test_original["数据来源"] = "原始测试集（固定）"
    print(f"原始训练验证集样本数：{len(df_train_val)} 条")
    print(f"固定测试集样本数（不拆分）：{len(df_test_original)} 条")

    # ========== 步骤2：分别预处理（训练验证集+固定测试集 + 无样本过滤） ==========
    # 训练验证集预处理：拼写校正→清洗→分词（保留所有样本，无过滤）
    df_train_val["corrected_text"] = df_train_val[text_column].apply(spell_correct)  # 拼写校正
    df_train_val["cleaned_text"] = df_train_val["corrected_text"].apply(clean_text)  # 清洗（标点处理）
    df_train_val["tokenized_text"] = df_train_val["cleaned_text"].apply(tokenize_text)  # 分词+停用词+词干
    # 无样本过滤：直接重置索引（保留所有样本，包括空tokenized_text）
    df_train_val_valid = df_train_val.reset_index(drop=True)

    # 测试集预处理：拼写校正→清洗→分词（保留所有样本，无过滤）
    df_test_original["corrected_text"] = df_test_original[text_column].apply(spell_correct)
    df_test_original["cleaned_text"] = df_test_original["corrected_text"].apply(clean_text)
    df_test_original["tokenized_text"] = df_test_original["cleaned_text"].apply(tokenize_text)
    # 无样本过滤：直接重置索引
    df_test_valid = df_test_original.reset_index(drop=True)

    # 统计空文本样本数（验证无过滤）
    empty_train = len(df_train_val_valid[df_train_val_valid["tokenized_text"] == ""])
    empty_test = len(df_test_valid[df_test_valid["tokenized_text"] == ""])
    print(f"预处理后训练验证集：{len(df_train_val_valid)} 条（含{empty_train}条空文本，保留）")
    print(f"预处理后固定测试集：{len(df_test_valid)} 条（含{empty_test}条空文本，保留）")

    # 衍生二分类标签（仅在训练验证集和固定测试集内各自衍生）
    df_train_val_valid["衍生二分类"] = df_train_val_valid[six_class_label].apply(convert_to_binary)
    df_test_valid["衍生二分类"] = df_test_valid[six_class_label].apply(convert_to_binary)
    print(f"\n训练验证集标签分布：")
    print(f"六分类：\n{df_train_val_valid[six_class_label].value_counts().sort_index()}")
    print(f"\n固定测试集标签分布：")
    print(f"六分类：\n{df_test_valid[six_class_label].value_counts().sort_index()}")

    # ========== 步骤3：仅对训练验证集进行8:1拆分（训练:验证） ==========
    print("\n📊 仅拆分训练验证集为8:1（训练:验证）...")
    X_train_val = df_train_val_valid["tokenized_text"]
    y_six_train_val = df_train_val_valid[six_class_label]
    y_binary_train_val = df_train_val_valid["衍生二分类"]

    # 按8:1拆分（总训练验证集的8/9作为训练集，1/9作为验证集）
    X_train, X_val, y_six_tr, y_six_val = train_test_split(
        X_train_val, y_six_train_val, 
        test_size=1/9,  # 1/(8+1) = 11.1%，接近10%
        random_state=random_seed,
        stratify=y_six_train_val if (y_six_train_val.value_counts().min() >= 2) else None
    )
    y_binary_tr = df_train_val_valid.loc[X_train.index, "衍生二分类"]
    y_binary_val = df_train_val_valid.loc[X_val.index, "衍生二分类"]

    print(f"训练集：{len(X_train)} 条（{len(X_train)/len(df_train_val_valid):.1%}）")
    print(f"验证集：{len(X_val)} 条（{len(X_val)/len(df_train_val_valid):.1%}）")
    print(f"固定测试集：{len(df_test_valid)} 条（独立，不参与拆分）")

    # ========== 步骤4：TF-IDF特征提取（用训练集拟合，统一转换验证集和固定测试集） ==========
    print("\n🔤 TF-IDF特征提取（训练集拟合，统一转换）...")
    tfidf = TfidfVectorizer(**tfidf_params)
    X_train_tfidf = tfidf.fit_transform(X_train)  # 仅用训练集拟合（空文本生成零向量）
    X_val_tfidf = tfidf.transform(X_val)  # 验证集用训练集的TF-IDF转换
    X_test_tfidf = tfidf.transform(df_test_valid["tokenized_text"])  # 固定测试集同样转换
    print(f"TF-IDF特征数：{len(tfidf.get_feature_names_out())} 个")

    # ========== 步骤5：SMOTE过采样（仅训练集，鲁棒性调整k_neighbors） ==========
    print("\n⚖️  训练集SMOTE过采样...")
    min_class_count = pd.Series(y_six_tr).value_counts().min()
    # 调整k_neighbors：确保至少为1，避免样本数不足报错（含零向量样本后）
    smote_k = max(1, min(2, min_class_count - 1))
    smote = SMOTE(random_state=random_seed, k_neighbors=smote_k)
    
    X_train_tfidf_smote, y_six_tr_smote = smote.fit_resample(X_train_tfidf, y_six_tr)
    print(f"过采样前训练集样本数：{X_train_tfidf.shape[0]} 条")
    print(f"过采样后训练集样本数：{X_train_tfidf_smote.shape[0]} 条")

    # ========== 步骤6：5折交叉验证（仅用训练集，XGBoost模型） ==========
    print(f"\n🔍 {cv_folds}折交叉验证（训练集）...")
    skf = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=random_seed)
    cv_six_metrics = {"accuracy": [], "precision": [], "recall": [], "f1": []}
    cv_binary_metrics = {"accuracy": [], "precision": [], "recall": [], "f1": []}

    for fold, (train_idx, val_idx) in enumerate(skf.split(X_train_tfidf_smote, y_six_tr_smote), 1):
        print(f"第{fold}折交叉验证...")
        X_cv_train, X_cv_val = X_train_tfidf_smote[train_idx], X_train_tfidf_smote[val_idx]
        y_cv_six_train, y_cv_six_val = y_six_tr_smote[train_idx], y_six_tr_smote[val_idx]
        y_cv_binary_train = [convert_to_binary(l) for l in y_cv_six_train]
        y_cv_binary_val = [convert_to_binary(l) for l in y_cv_six_val]

        # ========== 初始化XGBoost模型 ==========
        xgb_model = XGBClassifier(**xgb_params)
        xgb_model.fit(X_cv_train, y_cv_six_train)

        y_cv_six_pred = xgb_model.predict(X_cv_val)
        y_cv_binary_pred = [convert_to_binary(l) for l in y_cv_six_pred]

        # 交叉验证指标计算（不变）
        cv_six_metrics["accuracy"].append(accuracy_score(y_cv_six_val, y_cv_six_pred))
        cv_six_metrics["precision"].append(precision_score(y_cv_six_val, y_cv_six_pred, average="weighted", zero_division=0))
        cv_six_metrics["recall"].append(recall_score(y_cv_six_val, y_cv_six_pred, average="weighted", zero_division=0))
        cv_six_metrics["f1"].append(f1_score(y_cv_six_val, y_cv_six_pred, average="weighted", zero_division=0))

        cv_binary_metrics["accuracy"].append(accuracy_score(y_cv_binary_val, y_cv_binary_pred))
        cv_binary_metrics["precision"].append(precision_score(y_cv_binary_val, y_cv_binary_pred, average="binary", zero_division=0))
        cv_binary_metrics["recall"].append(recall_score(y_cv_binary_val, y_cv_binary_pred, average="binary", zero_division=0))
        cv_binary_metrics["f1"].append(f1_score(y_cv_binary_val, y_cv_binary_pred, average="binary", zero_division=0))

    # 交叉验证结果汇总（不变）
    cv_six_result = {k: f"{sum(v)/cv_folds:.4f}±{pd.Series(v).std():.4f}" for k, v in cv_six_metrics.items()}
    cv_binary_result = {k: f"{sum(v)/cv_folds:.4f}±{pd.Series(v).std():.4f}" for k, v in cv_binary_metrics.items()}

    print(f"\n📈 {cv_folds}折交叉验证结果（训练集）：")
    print("六分类任务：", cv_six_result)
    print("二分类任务：", cv_binary_result)

    # ========== 步骤7：最终模型训练+预测（验证集+固定测试集+零向量处理） ==========
    print("\n🤖 训练最终XGBoost模型...")
    final_xgb_model = XGBClassifier(**xgb_params)
    final_xgb_model.fit(X_train_tfidf_smote, y_six_tr_smote)

    # 预测验证集（零向量样本也会输出预测，无拒绝机制）
    y_six_val_pred = final_xgb_model.predict(X_val_tfidf)
    y_binary_val_pred = [convert_to_binary(l) for l in y_six_val_pred]
    # 预测固定测试集（核心：零向量样本也会输出预测，无拒绝机制）
    y_six_test_pred = final_xgb_model.predict(X_test_tfidf)
    y_binary_test_pred = [convert_to_binary(l) for l in y_six_test_pred]

    # ========== 步骤8：指标计算+输出（验证集+固定测试集） ==========
    val_six_metrics = {
        "Accuracy": accuracy_score(y_six_val, y_six_val_pred),
        "Precision": precision_score(y_six_val, y_six_val_pred, average="weighted", zero_division=0),
        "Recall": recall_score(y_six_val, y_six_val_pred, average="weighted", zero_division=0),
        "F1-Score": f1_score(y_six_val, y_six_val_pred, average="weighted", zero_division=0)
    }
    val_binary_metrics = {
        "Accuracy": accuracy_score(y_binary_val, y_binary_val_pred),
        "Precision": precision_score(y_binary_val, y_binary_val_pred, average="binary", zero_division=0),
        "Recall": recall_score(y_binary_val, y_binary_val_pred, average="binary", zero_division=0),
        "F1-Score": f1_score(y_binary_val, y_binary_val_pred, average="binary", zero_division=0)
    }

    # 固定测试集指标（所有模型对比的核心依据，含零向量样本的预测）
    test_six_metrics = {
        "Accuracy": accuracy_score(df_test_valid[six_class_label], y_six_test_pred),
        "Precision": precision_score(df_test_valid[six_class_label], y_six_test_pred, average="weighted", zero_division=0),
        "Recall": recall_score(df_test_valid[six_class_label], y_six_test_pred, average="weighted", zero_division=0),
        "F1-Score": f1_score(df_test_valid[six_class_label], y_six_test_pred, average="weighted", zero_division=0)
    }
    test_binary_metrics = {
        "Accuracy": accuracy_score(df_test_valid["衍生二分类"], y_binary_test_pred),
        "Precision": precision_score(df_test_valid["衍生二分类"], y_binary_test_pred, average="binary", zero_division=0),
        "Recall": recall_score(df_test_valid["衍生二分类"], y_binary_test_pred, average="binary", zero_division=0),
        "F1-Score": f1_score(df_test_valid["衍生二分类"], y_binary_test_pred, average="binary", zero_division=0)
    }

    print("\n" + "="*50)
    print("===== XGBoost模型最终结果（固定测试集） =====")
    print("="*50)
    print("\n【验证集指标】")
    print("六分类任务：")
    for k, v in val_six_metrics.items():
        print(f"  {k}: {v:.4f}")
    print("二分类任务：")
    for k, v in val_binary_metrics.items():
        print(f"  {k}: {v:.4f}")

    print("\n【固定测试集指标（模型对比核心）】")
    print("六分类任务：")
    for k, v in test_six_metrics.items():
        print(f"  {k}: {v:.4f}")
    print("二分类任务：")
    for k, v in test_binary_metrics.items():
        print(f"  {k}: {v:.4f}")

    # ========== 步骤9：保存结果（新增校正后文本，便于追溯） ==========
    print("\n💾 保存XGBoost模型结果文件...")
    # 保存交叉验证结果
    cv_result_df = pd.DataFrame({
        "任务": ["六分类"]*4 + ["二分类"]*4,
        "指标": list(cv_six_result.keys()) + list(cv_binary_result.keys()),
        "交叉验证结果（均值±标准差）": list(cv_six_result.values()) + list(cv_binary_result.values())
    })
    cv_result_df.to_csv(cv_result_path, index=False, encoding="utf-8-sig")

    # 保存固定测试集结果（包含校正后文本、空文本样本，便于追溯）
    test_result_df = df_test_valid.copy()
    test_result_df["预测_六分类"] = y_six_test_pred
    test_result_df["预测_衍生二分类"] = y_binary_test_pred
    test_result_df = test_result_df.rename(columns={
        six_class_label: "真实_六分类",
        "衍生二分类": "真实_衍生二分类"
    })
    # 新增校正后文本列，保留核心预处理步骤的结果
    core_columns = ["句子", "corrected_text", "cleaned_text", "tokenized_text", "数据来源", 
                   "真实_六分类", "预测_六分类", "真实_衍生二分类", "预测_衍生二分类"]
    test_result_df = test_result_df[core_columns]
    test_result_df.to_csv(test_result_path, index=False, encoding="utf-8-sig")

    print(f"✅ 所有结果已保存完成：")
    print(f"- 交叉验证结果：{cv_result_path}")
    print(f"- 固定测试集详细结果：{test_result_path}")
    print("\n🎉 XGBoost模型（固定测试集版本）训练全流程完成！可直接与其他模型对比测试集指标～")