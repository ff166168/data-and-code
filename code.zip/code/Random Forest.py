import pandas as pd
import re
import jieba
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier  # 随机森林分类器
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from imblearn.over_sampling import SMOTE
import warnings
warnings.filterwarnings('ignore')

# ---------------------- 新增：尝试导入拼写校正和词干处理库（兼容导入失败） ----------------------
try:
    import pycorrector  # 中文拼写校正
    import synonyms     # 中文同义词替换（模拟词干）
    CORRECT_AVAILABLE = True
    STEM_AVAILABLE = True
except ImportError:
    CORRECT_AVAILABLE = False
    STEM_AVAILABLE = False
    print("⚠️ 未安装pycorrector/synonyms，跳过拼写校正/词干处理（不影响代码运行）")

# ---------------------- 1. 配置参数（核心：固定原始测试集，不参与拆分） ----------------------
train_val_file = r"D:\桌面\LLM\训练验证集.xlsx"
test_file_original = r"D:\桌面\LLM\测试集.xlsx"  # 原始测试集固定为最终测试集
dict_file = r"D:\桌面\ML\关键词.txt"
stopwords_file = r"D:\桌面\数据\停用词\停用词3491.txt"

# 结果路径（标注“固定测试集+RandomForest”，区分版本）
cv_result_path = r"D:\桌面\RandomForest_5折交叉验证结果_固定100测试集.csv"
test_result_path = r"D:\桌面\RandomForest_测试集结果_固定100测试集.csv"  # 测试集=原始测试集

text_column = "句子"
six_class_label = "六分类"
random_seed = 42  # 保持随机种子一致，确保可复现

def convert_to_binary(label):
    return 0 if label == 0 else 1  # 二分类规则不变

# 特征参数（保持不变，保证对比公平）
tfidf_params = {
    "max_features": 600,
    "ngram_range": (1, 2),
    "min_df": 3,
    "max_df": 0.8
}

# 随机森林核心参数（适配类别不平衡、随机种子等关键设置）
rf_params = {
    "n_estimators": 100,  # 决策树的数量（默认100，可调整为200、300等）
    "criterion": "gini",  # 划分准则：gini（基尼系数）/entropy（信息熵）
    "max_depth": None,    # 树的最大深度（None表示不限制，可根据需求调整）
    "min_samples_split": 2,  # 分割内部节点所需的最小样本数
    "min_samples_leaf": 1,   # 叶节点所需的最小样本数
    "class_weight": "balanced",  # 处理类别不平衡（与原逻辑一致）
    "random_state": random_seed,  # 固定随机种子
    "n_jobs": -1,  # 并行运行的作业数（-1表示使用所有CPU核心，提升训练速度）
    "max_features": "sqrt",  # 划分时考虑的最大特征数（sqrt表示平方根，默认值）
}

cv_folds = 5  # 交叉验证折数不变

# ---------------------- 2. 加载词典+停用词（完全不变） ----------------------
try:
    with open(dict_file, 'r', encoding='utf-8') as f:
        dict_content = f.read().strip()
        custom_dict = re.split(r'[，、\s;；\n\r]+', dict_content)
        custom_dict = list({word.strip() for word in custom_dict if word.strip()})
    jieba.load_userdict(custom_dict)
    print(f"✅ 自定义关键词词典加载成功：共{len(custom_dict)}个词（已去重）")
except Exception as e:
    print(f"❌ 词典加载失败：{e}")
    custom_dict = []

try:
    with open(stopwords_file, 'r', encoding='utf-8') as f:
        stopwords = [line.strip() for line in f.readlines() if line.strip()]
    print(f"✅ 停用词加载成功：{len(stopwords)} 个")
except Exception as e:
    print(f"❌ 停用词加载失败：{e}")
    stopwords = []

# ---------------------- 3. 文本预处理（增强：拼写校正+词干处理，移除样本过滤） ----------------------
def clean_text(text):
    """标点、数字、空白符处理（保留原逻辑）"""
    if pd.isna(text):
        return ""
    text = str(text).strip()
    text = re.sub(r"[^\u4e00-\u9fa5a-zA-Z\s]", "", text)  # 移除非中文字母的符号
    text = re.sub(r"\d+", "", text)  # 移除数字
    text = re.sub(r"\s+", " ", text).strip()  # 合并空白符
    return text

def spell_correct(text):
    """中文拼写校正（兼容库不可用的情况）"""
    if not CORRECT_AVAILABLE or not text:
        return text
    try:
        corrected_text = pycorrector.correct(text)[0]
        return corrected_text
    except Exception:
        return text  # 出错时返回原文本

def stem_text(words):
    """中文词干处理（同义词替换模拟，兼容库不可用的情况）"""
    if not STEM_AVAILABLE or not words:
        return words
    stemmed_words = []
    for word in words:
        try:
            # 取第一个同义词（模拟词干），无同义词则保留原词
            syns = synonyms.nearby(word)[0]
            stem_word = syns[1] if len(syns) > 1 else word
            stemmed_words.append(stem_word)
        except Exception:
            stemmed_words.append(word)
    return stemmed_words

def tokenize_text(text):
    """分词+停用词去除+词干处理（保留所有样本，即使结果为空）"""
    if not text:
        return ""
    # 分词
    words = jieba.lcut(text)
    # 停用词去除+长度过滤（长度>1）
    words = [word for word in words if word not in stopwords and len(word) > 1]
    # 词干处理
    words = stem_text(words)
    # 即使结果为空，也返回空字符串（不过滤样本）
    return " ".join(words)

# ---------------------- 4. 核心逻辑：固定测试集，无样本过滤 + 随机森林适配 ----------------------
if __name__ == "__main__":
    # ========== 步骤1：分离原始测试集，不参与合并拆分 ==========
    print("\n📥 读取数据（固定原始测试集）...")
    # 1. 读取训练验证集（仅用于拆分训练和验证集）
    df_train_val = pd.read_excel(train_val_file)
    df_train_val["数据来源"] = "训练验证集"
    # 2. 读取原始测试集（直接作为最终测试集，不参与任何拆分）
    df_test_original = pd.read_excel(test_file_original)
    df_test_original["数据来源"] = "原始测试集（固定）"
    print(f"原始训练验证集样本数：{len(df_train_val)} 条")
    print(f"固定测试集样本数：{len(df_test_original)} 条")

    # ========== 步骤2：分别预处理（训练验证集+固定测试集，无样本过滤） ==========
    # 预处理训练验证集
    df_train_val["corrected_text"] = df_train_val[text_column].apply(spell_correct)  # 拼写校正
    df_train_val["cleaned_text"] = df_train_val["corrected_text"].apply(clean_text)  # 清洗
    df_train_val["tokenized_text"] = df_train_val["cleaned_text"].apply(tokenize_text)  # 分词处理
    # 移除样本过滤：直接使用所有样本（不再筛选tokenized_text != ""）
    df_train_val_valid = df_train_val.reset_index(drop=True)

    # 预处理固定测试集（保持独立，无样本过滤）
    df_test_original["corrected_text"] = df_test_original[text_column].apply(spell_correct)
    df_test_original["cleaned_text"] = df_test_original["corrected_text"].apply(clean_text)
    df_test_original["tokenized_text"] = df_test_original["cleaned_text"].apply(tokenize_text)
    # 移除样本过滤：直接使用所有样本
    df_test_valid = df_test_original.reset_index(drop=True)

    # 统计空文本样本数（验证无过滤）
    empty_train = len(df_train_val_valid[df_train_val_valid["tokenized_text"] == ""])
    empty_test = len(df_test_valid[df_test_valid["tokenized_text"] == ""])
    print(f"预处理后训练验证集：{len(df_train_val_valid)} 条（含{empty_train}条空文本，保留）")
    print(f"预处理后固定测试集：{len(df_test_valid)} 条（含{empty_test}条空文本，保留）")

    # 衍生二分类标签（仅在训练验证集和固定测试集内各自衍生）
    df_train_val_valid["衍生二分类"] = df_train_val_valid[six_class_label].apply(convert_to_binary)
    df_test_valid["衍生二分类"] = df_test_valid[six_class_label].apply(convert_to_binary)
    print(f"\n训练验证集标签分布：")
    print(f"六分类：\n{df_train_val_valid[six_class_label].value_counts().sort_index()}")
    print(f"\n固定测试集标签分布：")
    print(f"六分类：\n{df_test_valid[six_class_label].value_counts().sort_index()}")

    # ========== 步骤3：仅对训练验证集进行8:1拆分（训练:验证） ==========
    print("\n📊 仅拆分训练验证集为8:1（训练:验证）...")
    X_train_val = df_train_val_valid["tokenized_text"]
    y_six_train_val = df_train_val_valid[six_class_label]
    y_binary_train_val = df_train_val_valid["衍生二分类"]

    # 按8:1拆分（总训练验证集的8/9作为训练集，1/9作为验证集）
    stratify_param = y_six_train_val if (y_six_train_val.value_counts().min() >= 2) else None
    X_train, X_val, y_six_tr, y_six_val = train_test_split(
        X_train_val, y_six_train_val, 
        test_size=1/9,  # 1/(8+1) ≈ 11.1%，接近10%
        random_state=random_seed,
        stratify=stratify_param
    )
    # 正确获取二分类标签（索引匹配）
    y_binary_tr = y_binary_train_val.loc[X_train.index]
    y_binary_val = y_binary_train_val.loc[X_val.index]

    print(f"训练集：{len(X_train)} 条（{len(X_train)/len(df_train_val_valid):.1%}）")
    print(f"验证集：{len(X_val)} 条（{len(X_val)/len(df_train_val_valid):.1%}）")
    print(f"固定测试集：{len(df_test_valid)} 条（独立，不参与拆分）")

    # ========== 步骤4：TF-IDF特征提取（随机森林支持稀疏矩阵，无需转换） ==========
    print("\n🔤 TF-IDF特征提取（训练集拟合，统一转换）...")
    tfidf = TfidfVectorizer(**tfidf_params)
    X_train_tfidf = tfidf.fit_transform(X_train)  # 仅用训练集拟合
    X_val_tfidf = tfidf.transform(X_val)  # 验证集转TF-IDF
    X_test_tfidf = tfidf.transform(df_test_valid["tokenized_text"])  # 测试集转TF-IDF
    print(f"TF-IDF特征数：{len(tfidf.get_feature_names_out())} 个")

    # ========== 步骤5：SMOTE过采样（仅训练集，鲁棒性调整k_neighbors） ==========
    print("\n⚖️  训练集SMOTE过采样...")
    min_class_count = pd.Series(y_six_tr).value_counts().min()
    # 调整k_neighbors：确保至少为1，避免样本数不足报错
    smote_k = max(1, min(2, min_class_count - 1))
    smote = SMOTE(random_state=random_seed, k_neighbors=smote_k)
    
    X_train_tfidf_smote, y_six_tr_smote = smote.fit_resample(X_train_tfidf, y_six_tr)
    print(f"过采样前训练集样本数：{X_train_tfidf.shape[0]} 条")
    print(f"过采样后训练集样本数：{X_train_tfidf_smote.shape[0]} 条")

    # ========== 步骤6：5折交叉验证（替换为随机森林） ==========
    print(f"\n🔍 {cv_folds}折交叉验证（训练集）...")
    skf = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=random_seed)
    cv_six_metrics = {"accuracy": [], "precision": [], "recall": [], "f1": []}
    cv_binary_metrics = {"accuracy": [], "precision": [], "recall": [], "f1": []}

    for fold, (train_idx, val_idx) in enumerate(skf.split(X_train_tfidf_smote, y_six_tr_smote), 1):
        print(f"第{fold}折交叉验证...")
        X_cv_train, X_cv_val = X_train_tfidf_smote[train_idx], X_train_tfidf_smote[val_idx]
        y_cv_six_train, y_cv_six_val = y_six_tr_smote[train_idx], y_six_tr_smote[val_idx]
        y_cv_binary_train = [convert_to_binary(l) for l in y_cv_six_train]
        y_cv_binary_val = [convert_to_binary(l) for l in y_cv_six_val]

        # 实例化并训练随机森林模型
        rf_model = RandomForestClassifier(**rf_params)
        rf_model.fit(X_cv_train, y_cv_six_train)

        # 预测与指标计算
        y_cv_six_pred = rf_model.predict(X_cv_val)
        y_cv_binary_pred = [convert_to_binary(l) for l in y_cv_six_pred]

        # 交叉验证指标计算（不变）
        cv_six_metrics["accuracy"].append(accuracy_score(y_cv_six_val, y_cv_six_pred))
        cv_six_metrics["precision"].append(precision_score(y_cv_six_val, y_cv_six_pred, average="weighted", zero_division=0))
        cv_six_metrics["recall"].append(recall_score(y_cv_six_val, y_cv_six_pred, average="weighted", zero_division=0))
        cv_six_metrics["f1"].append(f1_score(y_cv_six_val, y_cv_six_pred, average="weighted", zero_division=0))

        cv_binary_metrics["accuracy"].append(accuracy_score(y_cv_binary_val, y_cv_binary_pred))
        cv_binary_metrics["precision"].append(precision_score(y_cv_binary_val, y_cv_binary_pred, average="binary", zero_division=0))
        cv_binary_metrics["recall"].append(recall_score(y_cv_binary_val, y_cv_binary_pred, average="binary", zero_division=0))
        cv_binary_metrics["f1"].append(f1_score(y_cv_binary_val, y_cv_binary_pred, average="binary", zero_division=0))

    # 交叉验证结果汇总（不变）
    cv_six_result = {k: f"{sum(v)/cv_folds:.4f}±{pd.Series(v).std():.4f}" for k, v in cv_six_metrics.items()}
    cv_binary_result = {k: f"{sum(v)/cv_folds:.4f}±{pd.Series(v).std():.4f}" for k, v in cv_binary_metrics.items()}

    print(f"\n📈 {cv_folds}折交叉验证结果（训练集）：")
    print("六分类任务：", cv_six_result)
    print("二分类任务：", cv_binary_result)

    # ========== 步骤7：最终模型训练+预测（验证集+固定测试集，含零向量） ==========
    print("\n🤖 训练最终Random Forest模型...")
    final_rf_model = RandomForestClassifier(**rf_params)
    final_rf_model.fit(X_train_tfidf_smote, y_six_tr_smote)

    # 预测验证集（所有样本都预测，无拒绝）
    y_six_val_pred = final_rf_model.predict(X_val_tfidf)
    y_binary_val_pred = [convert_to_binary(l) for l in y_six_val_pred]
    # 预测固定测试集（核心：用原始测试集评估，含零向量）
    y_six_test_pred = final_rf_model.predict(X_test_tfidf)
    y_binary_test_pred = [convert_to_binary(l) for l in y_six_test_pred]

    # ========== 步骤8：指标计算+输出（验证集+固定测试集） ==========
    val_six_metrics = {
        "Accuracy": accuracy_score(y_six_val, y_six_val_pred),
        "Precision": precision_score(y_six_val, y_six_val_pred, average="weighted", zero_division=0),
        "Recall": recall_score(y_six_val, y_six_val_pred, average="weighted", zero_division=0),
        "F1-Score": f1_score(y_six_val, y_six_val_pred, average="weighted", zero_division=0)
    }
    val_binary_metrics = {
        "Accuracy": accuracy_score(y_binary_val, y_binary_val_pred),
        "Precision": precision_score(y_binary_val, y_binary_val_pred, average="binary", zero_division=0),
        "Recall": recall_score(y_binary_val, y_binary_val_pred, average="binary", zero_division=0),
        "F1-Score": f1_score(y_binary_val, y_binary_val_pred, average="binary", zero_division=0)
    }

    # 固定测试集指标（所有模型对比的核心依据）
    test_six_metrics = {
        "Accuracy": accuracy_score(df_test_valid[six_class_label], y_six_test_pred),
        "Precision": precision_score(df_test_valid[six_class_label], y_six_test_pred, average="weighted", zero_division=0),
        "Recall": recall_score(df_test_valid[six_class_label], y_six_test_pred, average="weighted", zero_division=0),
        "F1-Score": f1_score(df_test_valid[six_class_label], y_six_test_pred, average="weighted", zero_division=0)
    }
    test_binary_metrics = {
        "Accuracy": accuracy_score(df_test_valid["衍生二分类"], y_binary_test_pred),
        "Precision": precision_score(df_test_valid["衍生二分类"], y_binary_test_pred, average="binary", zero_division=0),
        "Recall": recall_score(df_test_valid["衍生二分类"], y_binary_test_pred, average="binary", zero_division=0),
        "F1-Score": f1_score(df_test_valid["衍生二分类"], y_binary_test_pred, average="binary", zero_division=0)
    }

    print("\n" + "="*50)
    print("===== Random Forest模型最终结果（固定测试集） =====")
    print("="*50)
    print("\n【验证集指标】")
    print("六分类任务：")
    for k, v in val_six_metrics.items():
        print(f"  {k}: {v:.4f}")
    print("二分类任务：")
    for k, v in val_binary_metrics.items():
        print(f"  {k}: {v:.4f}")

    print("\n【固定测试集指标（模型对比核心）】")
    print("六分类任务：")
    for k, v in test_six_metrics.items():
        print(f"  {k}: {v:.4f}")
    print("二分类任务：")
    for k, v in test_binary_metrics.items():
        print(f"  {k}: {v:.4f}")

    # ========== 步骤9：保存结果（补全完整，含全样本信息） ==========
    print("\n💾 保存Random Forest模型结果文件...")
    # 保存交叉验证结果
    cv_result_df = pd.DataFrame({
        "任务": ["六分类"]*4 + ["二分类"]*4,
        "指标": list(cv_six_result.keys()) + list(cv_binary_result.keys()),
        "交叉验证结果（均值±标准差）": list(cv_six_result.values()) + list(cv_binary_result.values())
    })
    cv_result_df.to_csv(cv_result_path, index=False, encoding="utf-8-sig")

    # 保存固定测试集结果（包含原始句子、真实标签、预测标签，含空文本样本）
    test_result_df = df_test_valid.copy()
    test_result_df["预测_六分类"] = y_six_test_pred
    test_result_df["预测_衍生二分类"] = y_binary_test_pred
    test_result_df = test_result_df.rename(columns={
        six_class_label: "真实_六分类",
        "衍生二分类": "真实_衍生二分类"
    })
    # 保留核心列（新增校正后文本，便于追溯）
    core_columns = ["句子", "corrected_text", "cleaned_text", "tokenized_text", "数据来源", 
                   "真实_六分类", "预测_六分类", "真实_衍生二分类", "预测_衍生二分类"]
    test_result_df = test_result_df[core_columns]
    test_result_df.to_csv(test_result_path, index=False, encoding="utf-8-sig")

    print(f"✅ 所有结果已保存完成：")
    print(f"- 交叉验证结果：{cv_result_path}")
    print(f"- 固定测试集详细结果：{test_result_path}")
    print("\n🎉 Random Forest模型（固定测试集+无样本过滤版本）训练全流程完成！可直接与其他模型对比测试集指标～")