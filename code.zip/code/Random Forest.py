import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier  # 随机森林模型
from sklearn.metrics import precision_score, accuracy_score, recall_score, f1_score

# ---------------------- 配置参数（与之前一致） ----------------------
data_path = r"D:\桌面\excelexp_tfidf_cleaned.xlsx"
binary_label_col = "是否真实转型"
multi_label_col = "公司6分类标签"
random_seed = 42

# ---------------------- 数据加载与预处理（复用） ----------------------
def load_data(path):
    df = pd.read_excel(path)
    text_cols = ["公司名称", "完整句子", "cleaned_text", "tokenized_text"]
    candidate_cols = [col for col in df.columns if col not in text_cols + [binary_label_col, multi_label_col]]
    feature_cols = [col for col in candidate_cols if df[col].dtype in [np.float64, np.int64]]
    X = df[feature_cols].values
    
    y_binary = df[binary_label_col].replace("缺省", 0).fillna(0).astype(int)
    valid_binary = (y_binary == 0) | (y_binary == 1)
    X_binary = X[valid_binary]
    y_binary = y_binary[valid_binary]
    
    y_multi = df[multi_label_col].replace("缺省", 0).fillna(0).astype(int)
    valid_multi = (y_multi >= 0) & (y_multi <= 5)
    X_multi = X[valid_multi]
    y_multi = y_multi[valid_multi]
    
    return X_binary, y_binary, X_multi, y_multi

# ---------------------- 数据集划分（复用） ----------------------
def split_data(X, y):
    X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.2, random_state=random_seed)
    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=random_seed)
    return X_train, X_val, X_test, y_train, y_val, y_test

# ---------------------- 模型评估函数（复用） ----------------------
def evaluate_model(model, X_train, X_val, X_test, y_train, y_val, y_test, is_binary=True):
    model.fit(X_train, y_train)
    y_pred_train = model.predict(X_train)
    y_pred_val = model.predict(X_val)
    y_pred_test = model.predict(X_test)
    
    average = "binary" if is_binary else "weighted"
    metrics = {
        "train": {
            "Accuracy": accuracy_score(y_train, y_pred_train),
            "Precision": precision_score(y_train, y_pred_train, average=average, zero_division=1),
            "Recall": recall_score(y_train, y_pred_train, average=average),
            "F1-Score": f1_score(y_train, y_pred_train, average=average)
        },
        "val": {
            "Accuracy": accuracy_score(y_val, y_pred_val),
            "Precision": precision_score(y_val, y_pred_val, average=average, zero_division=1),
            "Recall": recall_score(y_val, y_pred_val, average=average),
            "F1-Score": f1_score(y_val, y_pred_val, average=average)
        },
        "test": {
            "Accuracy": accuracy_score(y_test, y_pred_test),
            "Precision": precision_score(y_test, y_pred_test, average=average, zero_division=1),
            "Recall": recall_score(y_test, y_pred_test, average=average),
            "F1-Score": f1_score(y_test, y_pred_test, average=average)
        }
    }
    return metrics

# ---------------------- 主函数（随机森林） ----------------------
if __name__ == "__main__":
    X_binary, y_binary, X_multi, y_multi = load_data(data_path)
    
    # 2分类任务
    print("===== 2分类 - 随机森林 =====")
    X_train, X_val, X_test, y_train, y_val, y_test = split_data(X_binary, y_binary)
    rf_model = RandomForestClassifier(n_estimators=100, random_state=random_seed)  # 100棵树
    metrics = evaluate_model(rf_model, X_train, X_val, X_test, y_train, y_val, y_test, is_binary=True)
    for data_type, m in metrics.items():
        print(f"\n{data_type}集指标:")
        for name, value in m.items():
            print(f"{name}: {value:.4f}")
    
    # 6分类任务
    print("\n===== 6分类 - 随机森林 =====")
    X_train, X_val, X_test, y_train, y_val, y_test = split_data(X_multi, y_multi)
    rf_model = RandomForestClassifier(n_estimators=100, random_state=random_seed)
    metrics = evaluate_model(rf_model, X_train, X_val, X_test, y_train, y_val, y_test, is_binary=False)
    for data_type, m in metrics.items():
        print(f"\n{data_type}集指标:")
        for name, value in m.items():
            print(f"{name}: {value:.4f}")